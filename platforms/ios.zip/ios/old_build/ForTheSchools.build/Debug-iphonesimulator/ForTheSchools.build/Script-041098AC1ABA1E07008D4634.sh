#!/bin/sh
sh /TestFairy/upload-dsym.sh -d ceaa88d8f6cfda9888b021167f1eb74ef0d4acc4

#!/bin/sh
cordova/lib/copy-www-build-step.sh
